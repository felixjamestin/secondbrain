const Constants = {
  appKeys: {
    sb: "SECONDBRAIN",
    rmed: "RAMANA_MAHARISHI_ENGLISH_DAILY",
    aed: "ADVAITA_ENGLIGH_DAILY",
    ted: "TAO_ENGLIGH_DAILY",
    bed: "BIBLE_ENGLISH_DAILY",
    bsd: "BIBLE_SPANISH_DAILY"
  }
};

export { Constants };
